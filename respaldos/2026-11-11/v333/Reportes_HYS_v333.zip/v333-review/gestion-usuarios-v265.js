/* Reportes HYS v265 — Gestión de usuarios centralizada.
 * Alta/edición secuencial, historial y acceso por Administrador general.
 * Solo el laboratorio FICTICIO tiene guardado. Producción no recibe nuevas escrituras.
 */
(function(root){
'use strict';
if(new URLSearchParams(location.search).get('embedded')==='otros')return;
const W=root.Hys265WorkerModel;
const Credentials=root.Hys274Credentials;
const B279=root.Hys279Backend;
const A278=root.Hys278AccessControl;
const nav=document.getElementById('hysToolsOptions');
if(!W||!Credentials||!A278||!B279||!nav)return;
const $=id=>document.getElementById(id);
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const clone=v=>JSON.parse(JSON.stringify(v));
const lab=root.HYS265_LAB_MODE===true&&!!root.Hys263Lab&&(/\/laboratorio-integral-v265\.html$/.test(location.pathname)||(root.HYS266_PREVIEW_ONLY===true&&/\/(?:v266-review|v267-review|v269-review|v270-review|v271-review|v272-review|v273-review|v274-review|v275-review|v276-review)\/index\.html$/.test(location.pathname)));
const labApi=lab?root.Hys263Lab:null;
const scopeNames={APR:'Prevencionistas',OTROS:'Supervisores, capataces y otros'};
const rights=[
 ['view','Consultar informes de otros usuarios'],
 ['pdf','Descargar PDF de otros usuarios'],
 ['review','Revisar y devolver informes'],
 ['approve','Aprobar informes'],
 ['close','Cerrar informes'],
 ['closeFlashReport','Autorizar cierre de Flash Report'],
 ['closeFinalReport','Autorizar cierre de Final Report'],
 ['editOthers','Modificar informes de otros'],
 ['areas','Administrar áreas'],
 ['users','Administrar usuarios'],
 ['activation','Activar o desactivar cuentas'],
 ['audit','Consultar auditoría']
];
const employment=[
 ['nombre','Nombre completo','text',true],

 ['cargo','Cargo','text',true],
 ['gerencia','Gerencia','text',true],
 ['empresa','Empresa empleadora / contratista','text',true],
 ['proyecto','Proyecto','text',true],
 ['celular','Celular','tel',false],
 ['correo_corporativo','Correo corporativo','email',false],
 ['correo_personal','Correo personal','email',false],
 ['fecha_ingreso','Fecha de ingreso','date',false],
 ['codigo_trabajador','Código interno del trabajador','text',false]
];
const panel=document.createElement('section');
panel.id='hys265UsersPanel';
panel.hidden=true;
panel.setAttribute('role','dialog');
panel.setAttribute('aria-modal','true');
panel.setAttribute('aria-labelledby','hys265Title');
panel.innerHTML='<div class="hys265-shell"><header class="hys265-header"><div><p class="hys265-eyebrow">ADMINISTRADOR GENERAL</p><h1 id="hys265Title">Gestión de usuarios</h1><p>Ficha del trabajador, rol, tarjetas, áreas, facultades e historial en un solo lugar.</p></div><button id="hys265Close" type="button" class="btn">Cerrar</button></header><p class="hys265-notice" id="hys265Notice" role="status"></p><nav class="hys265-tabs" aria-label="Gestión de usuarios"><button data-hys265-tab="create" type="button">Crear usuario</button><button data-hys265-tab="directory" type="button">Usuarios registrados</button><button data-hys265-tab="history" type="button">Historial</button><button data-hys265-tab="self" type="button">Mis datos laborales</button><button data-hys265-tab="quick" type="button">Permisos y facultades</button></nav><div id="hys265Content"></div></div>';
document.body.append(panel);
const state={tab:'directory',mode:'create',step:1,draft:null,selected:null,users:[],areas:[],faculties:[],history:[],filter:'',histFilter:'',dirty:false,loading:false,seq:0,accessTarget:null,accessMode:'suspend',accessEvents:null,accessBusy:false,turnos:[],profileTarget:null,profileRevision:0,profileReady:false,profileBusy:false,profileMode:'worker',profileError:'',quickFilter:'',quickTarget:null,quickBaseline:null};
// Credenciales temporales solo en memoria; jamás integradas a state.draft o al historial.
let credentialSecret='',credentialRepeat='',delivery=null;
function clearCredentials(){credentialSecret='';credentialRepeat='';delivery=null;}
const notice=(msg,warning=false)=>{const e=$('hys265Notice');e.textContent=msg;e.dataset.warning=warning?'true':'false'};
const userName=id=>state.users.find(x=>x.usuario_id===id)?.nombre||id||'Sin registro';
function isGlobal(){const a=root.__REPORTES_HYS_ACCESS__;return a?.profile?.activo===true&&a.profile.rol==='administrador_global'}
function showInRail(){const a=root.__REPORTES_HYS_ACCESS__;return isGlobal()&&!a?.selectedModule&&document.body.classList.contains('module-choice')}
function newButton(id,icon,label,full){
 const b=document.createElement('button');b.id=id;b.type='button';b.className='hys-admin-open';b.hidden=!showInRail();
 b.innerHTML='<span class="tools-option-icon" aria-hidden="true">'+icon+'</span><span class="tools-option-label">'+label+'</span><span class="tools-option-full">'+full+'</span>';return b;
}
const usersButton=newButton('hys265OpenUsers','♙','Usuarios','Gestión de usuarios');
// Reutilizar exactamente la pestaña histórica de Áreas y opciones; no crear una copia.
const areasButton=$('manageOpen242');
const oldUsers=$('usersOpen258');
const oldButtons=[...nav.querySelectorAll('button.hys-admin-open')];
const follow=oldButtons.find(n=>n.textContent.includes('Seguimiento'));
const appearance=$('appearanceOpen242');
// Solo rótulos del menú: las ventanas originales, botones y funciones no cambian.
// Texto breve al contraer, nombre completo en una línea al expandir.
for(const [button,shortText,fullText] of [
 [areasButton,'Áreas','Áreas y opciones'],
 [follow,'Seguimiento','Seguimiento'],
 [appearance,'Apariencia','Apariencia']
]){
 if(!button)continue;
 const short=button.querySelector('.tools-option-label');
 const full=button.querySelector('.tools-option-full');
 if(short)short.textContent=shortText;
 if(full)full.textContent=fullText;
}
nav.append(usersButton);
if(areasButton)nav.append(areasButton);
if(follow)nav.append(follow);
if(appearance)nav.append(appearance);
if(oldUsers)oldUsers.hidden=true;
for(const b of oldButtons)if(b!==areasButton&&b!==follow&&b!==appearance)b.hidden=true;
// Cada herramienta abre solo su propio panel; no apilar Gestión de usuarios sobre Áreas.
// Se usa captura para mantener también los manejadores originales y los del laboratorio.
nav.addEventListener('click',event=>{
 const button=event.target.closest('button');
 if(!button||!nav.contains(button))return;
 const id=button.id;
 if(!['hys265OpenUsers','manageOpen242','operationsOpen242','appearanceOpen242','hys285OpenPillars','hys305OpenAccidents'].includes(id)
    && button!==follow)return;
 if(id!=='hys265OpenUsers'&&!panel.hidden){
  if(!close()){event.preventDefault();event.stopImmediatePropagation();return}
 }
 if(id!=='manageOpen242'){
  const areasPanel=$('management242');
  if(areasPanel&&!areasPanel.hidden){
   const areaDraft=$('manageName242')?.value?.trim();
   if(areaDraft&&!confirm('Hay un nombre de área/opción sin guardar. ¿Descartarlo?')){
    event.preventDefault();event.stopImmediatePropagation();return;
   }
   areasPanel.hidden=true;
   const field=$('manageName242');if(field)field.value='';
  }
 }
 if(id!=='appearanceOpen242'){
  const appearancePanel=$('appearancePanel242');
  if(appearancePanel&&!appearancePanel.hidden){
   // Usar la función original de cierre, que protege cambios visuales no guardados.
   $('appearanceClose242')?.click();
   if(!appearancePanel.hidden){event.preventDefault();event.stopImmediatePropagation();return}
  }
 }
},true);
let inFlight=0;
async function readStore(){
 if(lab)return clone(labApi.get());
 const a=root.__REPORTES_HYS_ACCESS__;
 if(!isGlobal()||!root.reportesHysSupabase)throw Error('Se requiere iniciar sesión como Administrador general');
 const r=await root.reportesHysSupabase.rpc('hys242_listar_usuarios');
 if(r.error)throw r.error;
 const x=await root.reportesHysSupabase.from('areas_trabajo_v242').select('id,nombre,activa,modulo').in('modulo',W.modules).order('nombre');
 if(x.error)throw x.error;
 const faculty=await root.reportesHysSupabase.from('facultades_v242').select('usuario_id,modulo,revision,areas_ids,facultades');
 // No convertir fallas de red/RLS en 'sin facultades': podrían simular una revocación total.
 if(faculty.error)throw faculty.error;
 if(!Array.isArray(r.data)||!Array.isArray(x.data)||!Array.isArray(faculty.data))
   throw Error('Supabase devolvió datos incompletos de usuarios, áreas o facultades. No es seguro editar permisos.');
 return {users:r.data,areas:x.data,faculties:faculty.data,history:[]};
}
async function readHistory(){
 if(lab)return labApi.get().history;
 if(!isGlobal()||!root.reportesHysSupabase)return [];
 const r=await root.reportesHysSupabase.from('eventos_v242').select('id,fecha,actor_nombre,accion,motivo,anterior,nuevo,entidad').order('fecha',{ascending:false}).limit(60);
 const f=await root.reportesHysSupabase.from('auditoria_facultades_v242').select('fecha,actor_nombre,usuario_id,modulo,motivo,anterior,nuevo').order('fecha',{ascending:false}).limit(60);
 if(r.error)throw r.error;
 if(f.error)throw f.error;
 if(!Array.isArray(r.data)||!Array.isArray(f.data))
  throw Error('No se pudo verificar la integridad del historial de permisos.');
 const data=[...r.data,...f.data.map(x=>({...x,accion:'Facultades · '+scopeNames[x.modulo],usuario:x.usuario_id,actor:x.actor_nombre}))];
 return data.sort((a,b)=>String(b.fecha).localeCompare(String(a.fecha))).slice(0,100);
}
async function refresh(){
 const token=++inFlight,actor=root.__REPORTES_HYS_ACCESS__?.userId;
 const authorized=()=>token===inFlight&&!panel.hidden&&isGlobal()&&root.__REPORTES_HYS_ACCESS__?.userId===actor;
 state.loading=true;notice('Consultando información…');
 try{
  const data=await readStore();if(!authorized())return;
  const shifts=await B279.shifts().catch(()=>[]);if(!authorized())return;
  const history=state.tab==='history'?await readHistory():data.history||[];
  if(!authorized())return;
  // Publicar estado solo al confirmar TODOS los datos y la misma identidad.
  state.turnos=shifts;state.users=data.users;state.areas=data.areas;
  state.faculties=data.faculties;state.history=history;
  notice(lab?'Laboratorio ficticio: las operaciones se guardan solo en este navegador.':'Vista de desarrollo: la ficha laboral y el guardado unificado requieren una migración segura en Supabase; no se realizan escrituras.',!lab);
  render();
 }catch(e){if(authorized()){notice('No se pudo consultar: '+e.message,true);render()}}
 finally{if(token===inFlight)state.loading=false}
}
function abandon(){return !state.dirty||confirm('Hay información sin guardar. ¿Descartarla?')}
function show(tab){
 if(!abandon())return;
 clearCredentials();state.tab=tab;state.dirty=false;
 if(tab==='self'){openProfile(root.__REPORTES_HYS_ACCESS__?.userId,'self');return}
 if(tab==='create')resetDraft();
 if(tab==='quick'){state.quickTarget=null;state.quickBaseline=null;state.quickFilter=''}
 render();if(tab==='history')refresh();
}
function resetDraft(user=null){
 clearCredentials();
 state.selected=user?.usuario_id||null;state.mode=user?'edit':'create';state.step=1;state.dirty=false;
 const worker={...Object.fromEntries(W.fields.map(k=>[k,''])),...(user?.trabajador||{}),nombre:user?.nombre||user?.trabajador?.nombre||'',estado_laboral:user?.trabajador?.estado_laboral||(user?.activo===false?'suspendido':'activo')};
 const ambitos=user?clone(user.ambitos||{}):{};
 const faculties={};
 for(const m of W.modules){
  if(!ambitos[m])ambitos[m]={ver:m==='APR',editar:false,areas:state.areas.filter(a=>a.modulo===m&&a.activa).slice(0,1).map(a=>a.id)};
  const fac=state.faculties.find(x=>x.usuario_id===user?.usuario_id&&x.modulo===m);
  faculties[m]=fac&&user?.rol==='administrador_area'?clone({areas_ids:fac.areas_ids||[],facultades:fac.facultades||{}}):{areas_ids:[],facultades:{}};
 }
 state.draft={worker,cuenta:user?.cuenta?clone(user.cuenta):{correo_ingreso:worker.correo_corporativo?'corporativo':'personal',metodo:'automatica',estado:user?'sin_cambios':'alta_temporal_simulada'},rol:user?.rol&&W.roles.includes(user.rol)?user.rol:'usuario',ambitos,facultades:faculties,motivo:''};
}
function setTabStyle(){
 const selected=state.tab==='profile'?(state.profileMode==='self'?'self':'directory'):state.tab;
 panel.querySelectorAll('[data-hys265-tab]').forEach(b=>{b.classList.toggle('active',b.dataset.hys265Tab===selected);b.setAttribute('aria-current',b.dataset.hys265Tab===selected?'page':'false')});
}
function render(){
 setTabStyle();
 const content=$('hys265Content');content.replaceChildren();
 if(state.tab==='directory')renderDirectory(content);
 else if(state.tab==='history')renderHistory(content);
 else if(state.tab==='access')renderAccess(content);
 else if(state.tab==='profile')renderProfileEditor(content);
 else if(state.tab==='quick')renderQuickPermissions(content);
 else if(state.mode==='delivery')renderCredentialDelivery(content);
 else renderWizard(content);
}
function element(tag,txt,cls){const e=document.createElement(tag);if(txt!==undefined)e.textContent=txt;if(cls)e.className=cls;return e}
function action(label,callback,cls='btn'){const e=element('button',label,cls);e.type='button';e.onclick=callback;return e}
function openEdit(u){
 if(!abandon())return;
 clearCredentials();
 state.tab='create';resetDraft(u);render();
 notice('Editando la ficha de '+u.nombre+'. Se conserva el mismo flujo secuencial de creación.');
}
async function openProfile(userId,mode='worker'){
 if(!isGlobal()||lab||!userId)return;
 if(!abandon())return;
 clearCredentials();
 const target=state.users.find(u=>u.usuario_id===userId);
 if(!target||mode==='self'&&userId!==root.__REPORTES_HYS_ACCESS__?.userId){
  notice('No se pudo identificar una cuenta autorizada.',true);return;
 }
 if(mode!=='self'&&target.rol==='administrador_global'){notice('El Administrador general edita sus datos desde «Mis datos laborales».',true);return}
 state.tab='profile';state.profileMode=mode;state.profileTarget=userId;
 state.profileRevision=0;state.profileReady=false;state.profileError='';
 state.dirty=false;state.profileBusy=false;
 state.draft={worker:W.sanitize({nombre:target.nombre||'',estado_laboral:'activo'}),motivo:''};
 render();
 const at=userId;
 try{
  const cap=await B279.available();
  if(!cap.ready)throw Error(cap.reason);
  const data=await B279.read(at);
  if(state.tab!=='profile'||state.profileTarget!==at||panel.hidden)return;
  state.profileRevision=Number(data.revision)||0;
  state.draft.worker=W.sanitize({...state.draft.worker,...(data.trabajador||{})});
  state.profileReady=true;state.profileError='';
 }catch(e){
  if(state.tab==='profile'&&state.profileTarget===at){
   state.profileReady=false;state.profileError=e.message;
  }
 }
 if(state.tab==='profile'&&state.profileTarget===at&&!panel.hidden)render();
}
function renderProfileEditor(target){
 const u=state.users.find(x=>x.usuario_id===state.profileTarget);
 const own=state.profileMode==='self';
 const wrap=element('section',undefined,'hys265-card hys279-profile');
 wrap.append(element('h2',own?'Mis datos laborales y de contacto':'Ficha laboral · '+(u?.nombre||'Trabajador')));
 if(!state.draft||!u){
  wrap.append(element('p','Esta persona no está disponible. Regresa al directorio.'));target.append(wrap);return;
 }
 const desc=own?
  'Puedes completar o corregir tus propios datos. Se conservarán tu cuenta oficial y tus facultades administrativas.' :
  'Puedes actualizar los datos laborales sin cambiar las facultades, el rol ni el correo de ingreso de esta cuenta.';
 wrap.append(element('p',desc,'hys265-muted'));
 if(!state.profileReady){
  wrap.append(element('p',state.profileError||'Consultando disponibilidad del servicio de datos laborales…','hys279-warning'));
 }
 const pane=element('div',undefined,'hys279-worker-fields');stepWorker(pane,own);wrap.append(pane);
 const account=element('p','El correo de inicio de sesión de Supabase no cambia al editar estos contactos. La modificación de credenciales se gestiona por separado.','hys265-muted');
 wrap.append(account);
 const motiveLabel=document.createElement('label');motiveLabel.textContent='Motivo de modificación (mínimo 10 caracteres)';
 const reason=document.createElement('textarea');reason.id='hys279Reason';reason.rows=2;reason.maxLength=400;
 reason.value=state.draft.motivo||'';reason.placeholder='Describe el motivo de la actualización';
 reason.oninput=()=>{state.draft.motivo=reason.value;state.dirty=true};
 motiveLabel.append(reason);wrap.append(motiveLabel);
 const actions=element('div',undefined,'hys265-footer');
 actions.append(action('Volver a usuarios',()=>{if(state.profileBusy)return;show('directory')}));
 const saveButton=action('Guardar ficha laboral',async()=>{
  if(state.profileBusy||!state.profileReady||!isGlobal())return;
  const data=W.validate(state.draft.worker,state.users,state.profileTarget,
   {allowNoSupervisor:own,turnos:state.turnos});
  if(!data.ok){notice('Revisa la ficha: '+data.errors.join(' · '),true);return}
  const motivo=String(state.draft.motivo||'').trim();
  if(motivo.length<10){notice('Describe el motivo de la modificación con al menos 10 caracteres.',true);return}
  if(!confirm('¿Guardar los datos laborales reales de '+u.nombre+' en Supabase? No se modificarán roles ni permisos.'))return;
  state.profileBusy=true;saveButton.disabled=true;notice('Guardando y verificando la ficha en Supabase…');
  try{
   const saved=await B279.save(state.profileTarget,data.worker,state.profileRevision,motivo);
   const verified=await B279.read(state.profileTarget);
   if(verified.revision!==saved.revision)throw Error('La revisión del servidor cambió tras guardar. Consulta la ficha actualizada.');
   state.profileRevision=verified.revision;state.draft.worker=W.sanitize(verified.trabajador||{});
   state.draft.motivo='';state.dirty=false;
   notice('Ficha laboral guardada y confirmada por Supabase. Las facultades de la cuenta permanecen intactas.');
   await refresh();
  }catch(e){notice('No se guardó la ficha: '+e.message,true)}
  finally{state.profileBusy=false;saveButton.disabled=!state.profileReady}
 },'btn primary');
 saveButton.disabled=!state.profileReady||state.profileBusy;
 actions.append(saveButton);wrap.append(actions);target.append(wrap);
}

/* v301: acceso rápido en la quinta pestaña, dentro del mismo gestor.
   Ninguna modificación real de Supabase está autorizada en este modo de desarrollo. */
function quickEligible(u){return !!u&&u.rol!=='administrador_global'&&u.usuario_id!==root.__REPORTES_HYS_ACCESS__?.userId}
function quickSnapshot(d){return clone({rol:d.rol,ambitos:d.ambitos,facultades:d.facultades})}
function selectQuick(u){
 if(!isGlobal()||!quickEligible(u)||!abandon())return;
 clearCredentials();state.tab='quick';state.quickTarget=u.usuario_id;
 resetDraft(u);state.quickBaseline=quickSnapshot(state.draft);
 state.dirty=false;render();
 notice('Modifica únicamente rol, tarjetas, áreas y facultades de '+u.nombre+'. La ficha laboral y las credenciales no se editan aquí.');
}
function renderQuickPermissions(target){
 if(!isGlobal()){target.append(element('p','Acceso exclusivo del Administrador General.'));return}
 const card=element('section',undefined,'hys265-card hys301-quick');
 card.append(element('h2','Permisos y facultades'));
 card.append(element('p','Selecciona un usuario registrado para modificar sus autorizaciones sin recorrer los pasos de creación.','hys265-muted'));
 const selected=state.users.find(u=>u.usuario_id===state.quickTarget);
 if(state.quickTarget&&!quickEligible(selected)){state.quickTarget=null;state.quickBaseline=null;state.dirty=false}
 if(!state.quickTarget){
  const label=document.createElement('label');label.textContent='Buscar usuario registrado';
  const search=document.createElement('input');search.type='search';search.id='hys301Search';search.value=state.quickFilter;
  search.placeholder='Nombre, correo, cargo o rol…';
  search.oninput=()=>{state.quickFilter=search.value;quickRows()};
  label.append(search);card.append(label);
  const count=element('p',undefined,'hys265-muted');count.id='hys301Count';card.append(count);
  const list=element('div');list.id='hys301Rows';card.append(list);target.append(card);
  quickRows();return;
 }
 const user=state.users.find(u=>u.usuario_id===state.quickTarget);
 if(!user||!state.draft||state.selected!==user.usuario_id){
  card.append(element('p','No fue posible recuperar los permisos. Selecciona otra vez al usuario.','hys265-muted'));target.append(card);return;
 }
 const head=element('div',undefined,'hys265-line'),who=element('div');
 who.append(element('strong',user.nombre||'Usuario registrado'));
 who.append(element('small',(user.trabajador?.cargo||'Cargo no registrado')+' · '+(user.activo===false?'Cuenta inactiva':'Cuenta activa')));
 head.append(who,action('Elegir otro usuario',()=>{if(!abandon())return;state.quickTarget=null;state.quickBaseline=null;state.dirty=false;render()}));card.append(head);
 const roles=element('div',undefined,'hys301-quick-section');stepRoles(roles,true);card.append(roles);
 const facultades=element('div',undefined,'hys301-quick-section');stepSpecial(facultades,true);card.append(facultades);
 const reason=document.createElement('label');reason.textContent='Motivo del cambio';
 const input=document.createElement('textarea');input.id='hys301Reason';input.maxLength=500;input.rows=2;
 input.placeholder='Explica el cambio de facultades (mínimo 10 caracteres)';
 input.value=state.draft.motivo||'';input.oninput=()=>{state.draft.motivo=input.value;state.dirty=true};
 reason.append(input);card.append(reason);
 const summary=element('div',undefined,'hys301-summary');summary.id='hys301Summary';summary.setAttribute('role','status');card.append(summary);
 card.append(element('p','El guardado real de permisos aún está desactivado para proteger Supabase. Puedes revisar la propuesta sin modificar cuentas.','hys265-muted'));
 const footer=element('div',undefined,'hys265-footer');
 footer.append(action('Descartar cambios',()=>{
  if(!abandon())return;const current=state.users.find(u=>u.usuario_id===state.quickTarget);
  if(!quickEligible(current))return;resetDraft(current);state.quickBaseline=quickSnapshot(state.draft);state.dirty=false;render();notice('Propuesta descartada. Ningún permiso se modificó.');
 }));
 footer.append(action('Revisar propuesta',reviewQuick,'btn primary'));
 const save=action('Guardar permisos (pendiente)',()=>{});save.disabled=true;
 save.title='Requiere operación autorizada y auditable en Supabase';footer.append(save);
 card.append(footer);target.append(card);
}
function quickRows(){
 const rows=$('hys301Rows'),count=$('hys301Count');if(!rows||!count)return;
 rows.replaceChildren();const q=state.quickFilter.toLocaleLowerCase('es').trim();
 const all=state.users.filter(quickEligible);
 const matches=all.filter(u=>[u.nombre,u.rol,u.cuenta?.email,u.trabajador?.cargo].join(' ').toLocaleLowerCase('es').includes(q));
 count.textContent=matches.length+' de '+all.length+' usuarios';
 if(!matches.length){rows.append(element('p','No se encontraron usuarios.','hys265-muted'));return}
 for(const u of matches){
  const line=element('div',undefined,'hys301-person'),info=element('div');
  info.append(element('strong',u.nombre||'Usuario'));
  info.append(element('small',({usuario:'Usuario',supervisor:'Supervisor',administrador_area:'Administrador'}[u.rol]||'Rol')+' · '+(u.activo===false?'Cuenta inactiva':'Cuenta activa')));
  info.append(element('small',W.modules.filter(m=>u.ambitos?.[m]?.ver===true).map(m=>scopeNames[m]).join(' / ')||'Sin tarjetas'));
  line.append(info,action('Modificar permisos',()=>selectQuick(u)));rows.append(line);
 }
}
function reviewQuick(){
 if(!isGlobal()||state.tab!=='quick'||!state.quickTarget||!state.quickBaseline||!state.draft)return;
 const out=$('hys301Summary');if(!out)return;out.replaceChildren();
 const d=state.draft,valid=W.validConfiguration(d.rol,d.ambitos,d.facultades,state.areas);
 if(!valid.ok){out.append(element('p','Corrige la configuración: '+valid.errors.join('. ')));return}
 if(String(d.motivo||'').trim().length<10){out.append(element('p','Escribe el motivo con al menos 10 caracteres.'));return}
 const snapshot=quickSnapshot(d);
 if(JSON.stringify(snapshot)===JSON.stringify(state.quickBaseline)){out.append(element('p','No existen cambios de permisos para revisar.'));return}
 out.append(element('strong','Propuesta revisada · NO aplicada en Supabase'));
 out.append(element('p','Rol: '+({usuario:'Usuario',supervisor:'Supervisor',administrador_area:'Administrador'}[d.rol]||d.rol)));
 for(const m of W.modules){
  const a=d.ambitos[m]||{};
  out.append(element('p',scopeNames[m]+': '+(a.ver?'habilitada, '+(a.areas||[]).length+' áreas, '+(a.editar?'edición propia':'solo consulta'):'sin acceso')+
   '; facultades especiales: '+Object.values(d.facultades[m]?.facultades||{}).filter(Boolean).length));
 }
 out.append(element('p','Motivo: '+String(d.motivo).trim()));
}

function renderDirectory(target){
 const card=element('section',undefined,'hys265-card');const header=element('div',undefined,'hys265-line');
 header.append(element('h2','Usuarios registrados'));
 const box=document.createElement('label');box.textContent='Buscar persona';
 const search=document.createElement('input');search.type='search';search.value=state.filter;search.placeholder='Nombre, cargo o rol…';search.oninput=()=>{state.filter=search.value;renderDirectoryRows()};
 box.append(search);card.append(header,box);
 const count=element('p','', 'hys265-muted');count.id='hys265Count';
 const list=element('div');list.id='hys265DirectoryRows';card.append(count,list);target.append(card);
 renderDirectoryRows();
}
function renderDirectoryRows(){
 const rows=$('hys265DirectoryRows');if(!rows)return;rows.replaceChildren();
 const q=state.filter.toLocaleLowerCase('es').trim();
 const filtered=state.users.filter(u=>([u.nombre,u.rol,u.trabajador?.cargo,u.trabajador?.gerencia,u.trabajador?.empresa].join(' ').toLocaleLowerCase('es').includes(q)));
 $('hys265Count').textContent=filtered.length+' de '+state.users.length+' usuarios';
 if(!filtered.length){rows.append(element('p','No hay cuentas coincidentes.'));return}
 for(const u of filtered){
  const r=element('article',undefined,'hys265-person');
  const name=element('div');name.append(element('strong',u.nombre),element('small',(u.trabajador?.cargo||'Cargo no registrado')+' · '+({usuario:'Usuario',supervisor:'Supervisor',administrador_area:'Administrador',administrador_global:'Administrador general'}[u.rol]||u.rol)+' · '+(u.activo===false?'Inactivo':'Trabajador activo')+(u.cuenta?.estado==='pendiente_invitacion'?' · Invitación simulada pendiente':u.cuenta?.estado==='alta_temporal_simulada'?' · Alta temporal simulada':'')));
  const mod=element('small',W.modules.map(m=>u.ambitos?.[m]?.ver===true?scopeNames[m]:'').filter(Boolean).join(' / ')||'Sin tarjetas asignadas');name.append(mod);
  r.append(name);
  const actions=element('div',undefined,'hys265-inline');
  const edit=action('Administrar',()=>openEdit(u));edit.disabled=u.rol==='administrador_global';
  const access=action('Estado de acceso',()=>openAccess(u));access.disabled=!A278.validTarget(u,root.__REPORTES_HYS_ACCESS__?.userId)||lab;
  access.setAttribute('aria-label','Administrar acceso de '+u.nombre);
  const ficha=action('Ficha laboral',()=>openProfile(u.usuario_id,'worker'));
  ficha.disabled=lab||!isGlobal();
  actions.append(ficha,access,edit,action('Historial',()=>{clearCredentials();state.histFilter=u.usuario_id;state.tab='history';state.dirty=false;render();refresh()}));
  r.append(actions);rows.append(r);
 }
}
async function openAccess(u){
 if(!isGlobal()||lab||!A278.validTarget(u,root.__REPORTES_HYS_ACCESS__?.userId))return;
 clearCredentials();state.accessTarget=u.usuario_id;state.accessEvents=null;
 state.accessMode=u.activo?'suspend':'reactivate';state.tab='access';state.dirty=false;
 render();notice('Consulta y modificación de acceso conectadas al servidor real. Ningún cambio se aplica hasta confirmar.');
 const userId=u.usuario_id;
 try{
  const data=await A278.history(root.reportesHysSupabase,userId);
  if(state.tab==='access'&&state.accessTarget===userId&&!panel.hidden){state.accessEvents=data;render()}
 }catch(e){
  if(state.tab==='access'&&state.accessTarget===userId){state.accessEvents=[];notice(e.message,true);render()}
 }
}
function renderAccess(target){
 const u=state.users.find(x=>x.usuario_id===state.accessTarget);
 const card=element('section',undefined,'hys265-card hys278-access');
 card.append(element('h2','Estado de acceso del usuario'));
 if(!u){card.append(element('p','La cuenta ya no está disponible. Actualiza el directorio.'));card.append(action('Volver a usuarios',()=>show('directory')));target.append(card);return}
 const safeActor=root.__REPORTES_HYS_ACCESS__;
 const label=A278.labelFromHistory(state.accessEvents,u.activo);
 const info=element('dl',undefined,'hys265-summary');
 for(const [k,v] of [['Trabajador',u.nombre],['Rol',({administrador_area:'Administrador',administrador_global:'Administrador general',supervisor:'Supervisor',usuario:'Usuario'}[u.rol]||u.rol)],['Estado verificado',label],['ID de usuario',u.usuario_id]]){
  info.append(element('dt',k),element('dd',v));
 }
 card.append(info);
 card.append(element('p','Esta gestión utiliza Supabase real. Suspender o dar de baja impedirá la entrada a la aplicación en una nueva comprobación de acceso. Los informes y la auditoría permanecerán conservados.','hys265-muted'));
 card.append(element('p','Una sesión ya abierta puede seguir funcionando hasta que se revaliden sus permisos; la revocación inmediata de todas las sesiones requiere una función de servidor adicional.','hys265-muted'));
 const choices=element('fieldset',undefined,'hys278-options');
 choices.append(element('legend','Acción a ejecutar'));
 const validOps=u.activo?['suspend','terminate','remove_request']:['reactivate','terminate','remove_request'];
 if(!validOps.includes(state.accessMode))state.accessMode=validOps[0];
 const meanings={
  suspend:'Suspender temporalmente el acceso conservando su cuenta y sus informes',
  terminate:'Registrar desvinculación y dar de baja el acceso conservando la trazabilidad',
  remove_request:'Solicitar eliminación definitiva; bloquear el acceso y registrar la solicitud para revisión administrativa',
  reactivate:'Reactivar el ingreso con los permisos previamente asignados'
 };
 for(const op of validOps){
  const labelEl=document.createElement('label');labelEl.className='hys278-choice';
  const radio=document.createElement('input');radio.type='radio';radio.name='hys278Action';radio.value=op;
  radio.checked=state.accessMode===op;radio.disabled=state.accessBusy;
  radio.onchange=()=>{state.accessMode=op};
  labelEl.append(radio,document.createTextNode(meanings[op]));choices.append(labelEl);
 }
 card.append(choices);
 const reasonLabel=document.createElement('label');reasonLabel.textContent='Motivo obligatorio (mínimo 15 caracteres)';
 const reason=document.createElement('textarea');reason.id='hys278Reason';reason.rows=3;reason.maxLength=450;reason.placeholder='Ej. Suspensión temporal autorizada por RR.HH. debido a...';reason.disabled=state.accessBusy;
 reasonLabel.append(reason);card.append(reasonLabel);
 const confirmLabel=document.createElement('label');confirmLabel.textContent='Para confirmar, escribe exactamente el nombre completo: '+u.nombre;
 const name=document.createElement('input');name.id='hys278ConfirmName';name.type='text';name.maxLength=180;name.autocomplete='off';name.disabled=state.accessBusy;
 confirmLabel.append(name);card.append(confirmLabel);
 card.append(element('p','La solicitud de eliminación NO borra cuentas ni documentos: registra la solicitud, bloquea el acceso y conserva informes, compromisos y auditorías mientras se revisan responsabilidades y restricciones legales.','hys265-muted'));
 const buttons=element('div',undefined,'hys265-footer');
 buttons.append(action('Volver a usuarios',()=>{if(!state.accessBusy)show('directory')}));
 const submit=action('Confirmar cambio de acceso',async()=>{
  if(state.accessBusy||lab)return;
  const operation=state.accessMode,why=reason.value,confirmed=name.value;
  const actor=root.__REPORTES_HYS_ACCESS__;
  const error=A278.validate({access:actor,target:u,operation,reason:why,confirmName:confirmed});
  if(error){notice(error,true);return}
  const details=A278.tags[operation];
  if(!confirm(details.label+' de «'+u.nombre+'»?\\nEsta acción cambiará el estado REAL del usuario en Supabase y quedará auditada.'))return;
  state.accessBusy=true;submit.disabled=true;
  notice('Verificando permisos y actualizando el estado en Supabase...');
  try{
   const applied=await A278.apply({client:root.reportesHysSupabase,access:actor,target:u,operation,reason:why,confirmName:confirmed});
   const events=await A278.history(root.reportesHysSupabase,u.usuario_id).catch(()=>[]);
   state.accessEvents=events;
   state.accessBusy=false;
   state.accessMode=applied.user.activo?'suspend':'reactivate';
   await refresh();
   if(state.tab!=='access'||state.accessTarget!==applied.user.usuario_id)return;
   notice('Estado de acceso confirmado por Supabase. Operación: '+details.label+'. Se registró el motivo en auditoría.');
  }catch(e){
   notice('No se confirmó la operación: '+e.message,true);
  }finally{state.accessBusy=false;submit.disabled=false}
 },'btn primary');
 submit.disabled=state.accessBusy||!A278.allowedActor(safeActor);
 buttons.append(submit);card.append(buttons);
 const audit=element('section',undefined,'hys278-audit');
 audit.append(element('h3','Últimos movimientos de acceso'));
 if(state.accessEvents===null)audit.append(element('p','Consultando auditoría...','hys265-muted'));
 else if(!state.accessEvents.length)audit.append(element('p','No hay cambios de acceso anteriores registrados con la nueva clasificación.','hys265-muted'));
 else for(const e of state.accessEvents.slice(0,6)){
  const row=element('p',new Date(e.fecha).toLocaleString('es-CL')+' · '+String(e.motivo||'')+' · '+(e.actor_nombre||'Administrador'),'hys265-muted');
  audit.append(row);
 }
 card.append(audit);
 target.append(card);
}
function renderHistory(target){
 const card=element('section',undefined,'hys265-card');card.append(element('h2','Historial de gestión de usuarios'));
 card.append(element('p','Registra creaciones, modificaciones, roles, tarjetas, áreas y facultades, con fecha, responsable y motivo. No es editable.','hys265-muted'));
 const controls=element('div',undefined,'hys265-inline');
 const filter=document.createElement('select');filter.setAttribute('aria-label','Filtrar historial por usuario');filter.append(new Option('Todos los usuarios',''));
 for(const u of state.users)filter.add(new Option(u.nombre,u.usuario_id));filter.value=state.histFilter;
 filter.onchange=()=>{state.histFilter=filter.value;render()};
 controls.append(filter,action('Actualizar historial',()=>refresh()));card.append(controls);
 const results=element('div',undefined,'hys265-history');
 let events=state.history||[];
 if(state.histFilter)events=events.filter(x=>x.usuario===state.histFilter||x.entidad===state.histFilter||x.usuario_id===state.histFilter);
 if(!events.length)results.append(element('p','No hay acciones registradas para este filtro.'));
 for(const event of events.slice(0,100)){
  const item=element('article',undefined,'hys265-history-item');
  item.append(element('strong',event.accion||'Modificación de cuenta'));
  const who=event.usuario||event.usuario_id||event.entidad||'';
  item.append(element('p',(event.actor||event.actor_nombre||'Administrador general')+' · '+(event.fecha?new Date(event.fecha).toLocaleString('es-CL'):'Fecha no informada')+' · '+userName(who)));
  item.append(element('p','Motivo: '+(event.motivo||'No indicado')));
  const before=event.anterior,after=event.nuevo;
  if(before||after){
   const d=document.createElement('details');const summary=document.createElement('summary');summary.textContent='Valores anteriores y nuevos';d.append(summary);
   const p=document.createElement('pre');p.textContent='Anterior:\n'+JSON.stringify(W.redactAudit(before||{}),null,2)+'\n\nNuevo:\n'+JSON.stringify(W.redactAudit(after||{}),null,2);d.append(p);item.append(d);
  }
  results.append(item);
 }
 card.append(results);target.append(card);
}
function renderWizard(target){
 if(!state.draft)resetDraft();
 const d=state.draft;
 const main=element('section',undefined,'hys265-card');
 const h=element('div',undefined,'hys265-line');
 h.append(element('h2',(state.mode==='edit'?'Modificar trabajador':'Crear trabajador')+' · Paso '+state.step+' de 5'));
 h.append(element('span',['','Ficha laboral','Crear cuenta','Rol y tarjetas','Áreas y facultades','Revisar y guardar'][state.step],'hys265-step'));
 main.append(h);
 const stages=element('div',undefined,'hys265-stages');
 for(let i=1;i<=5;i++){const e=element('span',i<=state.step?'●':'○');e.classList.toggle('current',i===state.step);stages.append(e)}main.append(stages);
 const pane=element('div');pane.id='hys265StepContent';main.append(pane);
 if(state.step===1)stepWorker(pane);
 if(state.step===2)stepAccount(pane);
 if(state.step===3)stepRoles(pane);
 if(state.step===4)stepSpecial(pane);
 if(state.step===5)stepReview(pane);
 const error=element('div',undefined,'hys265-inline-error');
 error.id='hys265InlineError';error.hidden=true;error.setAttribute('role','alert');
 main.append(error);
 const foot=element('div',undefined,'hys265-footer');
 foot.append(action('Descartar',()=>{if(!abandon())return;state.tab='directory';state.dirty=false;render()}));
 if(state.step>1)foot.append(action('Anterior',()=>{state.step--;render()}));
 if(state.step<5)foot.append(action('Continuar',()=>goNext(),'btn primary'));
 else foot.append(action(lab?'Guardar usuario y permisos de prueba':'Integración pendiente (sin guardar)',()=>save(),'btn primary'));
 main.append(foot);target.append(main);
}
function field(k,label,type,required){
 const holder=document.createElement('label');holder.textContent=label+(required?' *':'');
 const input=document.createElement('input');input.type=type;input.name=k;input.value=state.draft.worker[k]||'';input.required=required;
 if(k==='rut')input.placeholder='12.345.678-5';
 if(k==='celular')input.placeholder='+56 9 XXXX XXXX';
 input.maxLength=type==='email'?254:k==='nombre'?150:200;
 input.oninput=()=>{state.draft.worker[k]=input.value;state.dirty=true};
 holder.append(input);return holder;
}
function selectField(name,label,values){
 const holder=document.createElement('label');holder.textContent=label;
 const control=document.createElement('select');control.name=name;
 for(const [value,title]of values)control.append(new Option(title,value));
 control.value=state.draft.worker[name]||values[0]?.[0]||'';
 control.onchange=()=>{state.draft.worker[name]=control.value;state.dirty=true};
 holder.append(control);return holder;
}
function stepWorker(p,own=state.tab==='profile'&&state.profileMode==='self'){
 p.append(element('h3','1. Identificación, información laboral y contacto'));
 p.append(element('p','La ficha usa documentos chilenos y extranjeros. El número de documento se guarda como texto para preservar letras y ceros iniciales.','hys265-muted'));
 const grid=element('div',undefined,'hys265-grid');
 const worker=state.draft.worker;
 grid.append(field('nombre','Nombre completo','text',true));
 const country=field('pais_documento','País del documento','text',true);
 const countryInput=country.querySelector('input');
 countryInput.placeholder='Escribe el país del documento';
 countryInput.autocomplete='off';
 grid.append(country);
 const type=document.createElement('label');type.textContent='Tipo de documento *';
 const docType=document.createElement('select');docType.name='tipo_documento';
 for(const [v,title]of [['rut','RUT chileno'],['ci','Cédula de identidad / CI'],['dni','DNI / Documento nacional'],['pasaporte','Pasaporte'],['otro','Otro documento']])docType.add(new Option(title,v));
 docType.value=worker.tipo_documento||'rut';
 docType.onchange=()=>{worker.tipo_documento=docType.value;state.dirty=true;render()};
 type.append(docType);grid.append(type);
 const number=field('rut','Número de identificación','text',true);const idInput=number.querySelector('input');
 idInput.maxLength=40;idInput.dataset.previousValue=worker.rut||'';idInput.placeholder=worker.tipo_documento==='rut'?'12.345.678-5':'Ej. 00AB1234-8';
 const codeInputLater=()=>grid.querySelector('[name="codigo_trabajador"]');
 idInput.addEventListener('input',()=>{
  const code=codeInputLater();
  if(code&&(!worker.codigo_trabajador||worker.codigo_trabajador===idInput.dataset.previousValue)){
   code.value=idInput.value;worker.codigo_trabajador=idInput.value;
  }
  idInput.dataset.previousValue=idInput.value;
 });
 grid.append(number);
 for(const [key,label,type,required]of employment){
  if(key==='nombre')continue;
  grid.append(field(key,label,type,required));
 }
 const employees=state.users.filter(x=>x.activo!==false&&x.usuario_id!==state.profileTarget&&x.usuario_id!==state.selected);
 const supervisors=[['',own?'Sin supervisor asignado (Administrador general)':'Seleccione un supervisor responsable'],
  ...employees.map(x=>[x.usuario_id,x.nombre+' · '+(x.trabajador?.cargo||x.rol)])];
 grid.append(selectField('supervisor_id',own?'Supervisor responsable (opcional)':'Supervisor responsable *',supervisors));
 grid.append(selectField('estado_laboral','Estado laboral',[['activo','Activo'],['suspendido','Suspendido'],['desvinculado','Desvinculado']]));
 const allowedTurnos=[...new Set(state.turnos||[])];
 const old=worker.turno;
 if(old&&!allowedTurnos.includes(old))allowedTurnos.push(old);
 grid.append(selectField('turno','Régimen de turno (administrable en Áreas y opciones)',[['','Sin régimen asignado'],...allowedTurnos.map(v=>[v,v.toLowerCase()])]));
 if(!state.turnos?.length)p.append(element('p','La lista de regímenes laborales todavía no está habilitada en el servidor. No se toman opciones de Día/Noche del informe diario.','hys279-warning'));
 grid.append(selectField('preferencia_contacto','Preferencia de contacto',[
  ['todas','Todas las vías de contacto registradas'],['corporativo','Correo corporativo'],['personal','Correo personal'],['celular','Celular']
 ]));
 p.append(grid);
 p.append(element('p','Es obligatorio registrar al menos uno de los dos correos. La opción «Todas» utilizará los canales registrados y disponibles, pero el envío de notificaciones depende de su integración posterior.','hys265-muted'));
 if(own)p.append(element('p','Editar estos datos no modifica tu rol, permisos, contraseña ni condición de Administrador general. El estado laboral es informativo y no sustituye el control de acceso.','hys265-muted'));
}
function fillWorkerSample(){
 if(!lab)return;
 const supervisor=state.users.find(u=>u.activo!==false&&u.usuario_id==='prueba-supervisor')||state.users.find(u=>u.activo!==false&&u.usuario_id!==state.selected);
 if(!supervisor){showInlineError('No hay un supervisor ficticio disponible para seleccionar.');return}
 const used=new Set(state.users.map(u=>W.rutParts(u.trabajador?.rut||'')?.normalized).filter(Boolean));
 let rut='';
 for(let n=90000000;n<90010000&&!rut;n++){
  for(const dv of '0123456789K'){
   const candidate=n+'-'+dv;
   if(W.validRut(candidate)&&!used.has(candidate)){rut=candidate;break}
  }
 }
 if(!rut){showInlineError('No hay RUT ficticio disponible para el ensayo.');return}
 const serial=(labApi?.get()?.rev||0)+1;
 Object.assign(state.draft.worker,{
  nombre:'Trabajador Ficticio de Prueba '+serial,
  rut,cargo:'Capataz de prueba',gerencia:'Gerencia ficticia',
  supervisor_id:supervisor.usuario_id,empresa:'Empresa de pruebas',proyecto:'Proyecto simulado',
  celular:'',correo_personal:'ficticio.personal'+serial+'@example.test',
  correo_corporativo:'ficticio.corporativo'+serial+'@example.test',
  estado_laboral:'activo'
 });
 state.draft.cuenta={correo_ingreso:'corporativo',metodo:'automatica',estado:'alta_temporal_simulada'};
 state.dirty=true;render();
 notice('Ficha de prueba completada. Ahora puedes pulsar Continuar.');
}

async function copyAccess(email,password){
 const message=Credentials.deliveryText(email,password,lab);
 try{
  if(navigator.clipboard?.writeText)await navigator.clipboard.writeText(message);
  else{
   const temp=document.createElement('textarea');temp.value=message;
   temp.style.cssText='position:fixed;left:-10000px;top:0';document.body.append(temp);temp.select();
   let copied=false;try{copied=document.execCommand('copy')}finally{temp.remove()}
   if(!copied)throw Error('Portapapeles no disponible');
  }
  notice('Datos copiados. Entrégalos únicamente al trabajador por un canal privado.');
 }catch{notice('No fue posible copiar el acceso automáticamente; puedes seleccionar la contraseña visible.',true)}
}
async function shareAccess(email,password){
 if(!navigator.share){await copyAccess(email,password);return}
 try{await navigator.share({title:'Acceso temporal Reportes HYS',text:Credentials.deliveryText(email,password,lab)})}
 catch(e){if(e?.name!=='AbortError')notice('No se pudo compartir el acceso. Utiliza el botón Copiar.',true)}
}
function accessButtons(target,email,password,method,confirmation){
 const actions=element('div',undefined,'hys265-inline');
 const check=()=>{const v=Credentials.validate(method,password(),confirmation());if(!v.ok){notice(v.error,true);return false}return true};
 actions.append(action('Copiar acceso',()=>{if(check())copyAccess(email,password())}));
 actions.append(action('Compartir acceso',()=>{if(check())shareAccess(email,password())},'btn primary'));
 target.append(actions);
}
function renderCredentialDelivery(target){
 if(!delivery){state.mode='create';render();return}
 const data=delivery,card=element('section',undefined,'hys265-card hys274-delivery');
 card.append(element('h2','Entrega de acceso · una sola vez'));
 card.append(element('p',lab?'Cuenta FICTICIA guardada; esta contraseña no permite iniciar sesión real.':'Entrega privada al trabajador.','hys265-muted'));
 card.append(element('p','Correo de ingreso: '+data.email));
 if(data.secret){
  const label=document.createElement('label');label.textContent='Contraseña temporal';
  const field=document.createElement('input');field.type='text';field.readOnly=true;field.autocomplete='off';field.value=data.secret;
  label.append(field);card.append(label);
  accessButtons(card,data.email,()=>data.secret,data.method,()=>data.secret);
 }else card.append(element('p','Se eligió invitación por correo. En el laboratorio no se envían mensajes.','hys265-muted'));
 card.append(element('p','El acceso se ocultará al cerrar o finalizar esta pantalla. No se conserva la contraseña en los registros.','hys265-muted'));
 card.append(action('Finalizar y ver usuarios registrados',()=>{clearCredentials();state.tab='directory';resetDraft();render()},'btn primary'));
 target.append(card);
}
function stepAccount(p){
 p.append(element('h3','2. Creación de cuenta'));
 p.append(element('p','Elige el correo de ingreso y el método de creación. La contraseña puede generarse automáticamente o escribirse de manera manual.','hys265-muted'));
 const d=state.draft,account=d.cuenta;
 const emailOptions=[];
 if(d.worker.correo_corporativo?.trim())emailOptions.push(['corporativo','Corporativo · '+d.worker.correo_corporativo.trim()]);
 if(d.worker.correo_personal?.trim())emailOptions.push(['personal','Personal · '+d.worker.correo_personal.trim()]);
 if(!emailOptions.length){p.append(element('p','No hay correo válido. Regresa a Ficha laboral.','hys265-muted'));return}
 if(!emailOptions.some(([v])=>v===account.correo_ingreso))account.correo_ingreso=emailOptions[0][0];
 const emailLabel=document.createElement('label');emailLabel.textContent='Correo para iniciar sesión *';
 const emailSelect=document.createElement('select');
 for(const [value,title] of emailOptions)emailSelect.add(new Option(title,value));
 emailSelect.value=account.correo_ingreso;emailSelect.disabled=state.mode==='edit';
 emailSelect.onchange=()=>{account.correo_ingreso=emailSelect.value;state.dirty=true;render()};
 emailLabel.append(emailSelect);p.append(emailLabel);
 const methodLabel=document.createElement('label');methodLabel.textContent='Método de creación *';
 const methodSelect=document.createElement('select');
 for(const [value,title] of [['automatica','Generar contraseña automática'],['manual','Crear contraseña manualmente'],['invitacion','Invitación por correo']])methodSelect.add(new Option(title,value));
 if(!['automatica','manual','invitacion'].includes(account.metodo))account.metodo='invitacion';
 methodSelect.value=account.metodo;methodSelect.disabled=state.mode==='edit';
 methodSelect.onchange=()=>{
  account.metodo=methodSelect.value;credentialSecret='';credentialRepeat='';state.dirty=true;render();
 };
 methodLabel.append(methodSelect);p.append(methodLabel);
 const candidate=W.validateAccount(account,d.worker,state.mode==='edit');
 if(state.mode==='edit'){
  p.append(element('p','Cuenta existente: no se modifica su contraseña desde esta ficha.','hys265-muted'));
 }else if(account.metodo!=='invitacion'){
  const automatic=account.metodo==='automatica';
  const card=element('div',undefined,'hys265-module hys274-credential');
  if(automatic&&!credentialSecret){try{credentialSecret=Credentials.generate(20)}catch(e){notice(e.message,true)}}
  const passLabel=document.createElement('label');passLabel.textContent=automatic?'Contraseña generada automáticamente *':'Escribe la contraseña temporal *';
  const pass=document.createElement('input');pass.id='hys274Password';pass.type=automatic?'text':'password';pass.readOnly=automatic;
  pass.autocomplete='new-password';pass.maxLength=128;pass.spellcheck=false;pass.value=credentialSecret;
  if(!automatic)pass.oninput=()=>{credentialSecret=pass.value;state.dirty=true};
  passLabel.append(pass);card.append(passLabel);
  if(automatic){
   card.append(action('Generar otra contraseña',()=>{try{credentialSecret=Credentials.generate(20);state.dirty=true;render()}catch(e){notice(e.message,true)}}));
  }else{
   const repeatLabel=document.createElement('label');repeatLabel.textContent='Confirma la contraseña manual *';
   const repeat=document.createElement('input');repeat.type='password';repeat.value=credentialRepeat;repeat.maxLength=128;repeat.autocomplete='new-password';
   repeat.oninput=()=>{credentialRepeat=repeat.value;state.dirty=true};repeatLabel.append(repeat);card.append(repeatLabel);
   card.append(action('Mostrar / ocultar contraseña',()=>{const visible=pass.type==='text';pass.type=visible?'password':'text';repeat.type=visible?'password':'text'}));
  }
  card.append(element('p','Mínimo 12 caracteres, con mayúsculas, minúsculas, números y símbolos. No se guarda la contraseña en la ficha ni en el historial.','hys265-muted'));
  accessButtons(card,candidate.cuenta.email,()=>credentialSecret,account.metodo,()=>credentialRepeat);
  p.append(card);
 }else p.append(element('p','Invitación por correo: el laboratorio no enviará mensajes.','hys265-muted'));
 const meta=element('div',undefined,'hys265-module');
 meta.append(element('strong',state.mode==='edit'?'Cuenta existente':'Cuenta nueva: pendiente de confirmar'));
 meta.append(element('p','Correo: '+(candidate.cuenta.email||'No válido'),'hys265-muted'));
 meta.append(element('p',lab?'SOLO PRUEBAS: esta contraseña se puede copiar o compartir como demostración, pero no es una cuenta real de Supabase.':'La creación real sigue desactivada hasta integrar un servicio de servidor seguro.','hys265-muted'));
 p.append(meta);
}
function stepRoles(p,quick=false){
 p.append(element('h3',quick?'Rol y tarjetas permitidas':'3. Rol y tarjetas permitidas'));
 const label=document.createElement('label');label.textContent='Rol de la aplicación';
 const role=document.createElement('select');
 for(const [value,title]of [['usuario','Usuario'],['supervisor','Supervisor'],['administrador_area','Administrador']])role.append(new Option(title,value));
 role.value=state.draft.rol;role.onchange=()=>{
  const before=state.draft.rol;state.draft.facultades=W.transition(before,role.value,state.draft.facultades,state.draft.ambitos);
  state.draft.rol=role.value;state.dirty=true;render();
 };
 label.append(role);p.append(label);
 p.append(element('p','El cargo laboral y el rol de la aplicación son independientes. Al salir o entrar nuevamente al rol Administrador todas las facultades especiales comienzan desmarcadas.','hys265-muted'));
 for(const m of W.modules){
  const a=state.draft.ambitos[m];const card=element('section',undefined,'hys265-module');
  const header=document.createElement('label');header.className='hys265-checkline';
  const enabled=document.createElement('input');enabled.type='checkbox';enabled.checked=a.ver===true;
  enabled.onchange=()=>{a.ver=enabled.checked;if(enabled.checked&&!a.areas?.length)a.areas=available(m).slice(0,1).map(x=>x.id);if(!enabled.checked){a.editar=false;state.draft.facultades[m]={areas_ids:[],facultades:{}}}state.dirty=true;render()};
  header.append(enabled,document.createTextNode(scopeNames[m]));card.append(header);
  if(a.ver){
   const edit=document.createElement('label');edit.className='hys265-checkline';
   const check=document.createElement('input');check.type='checkbox';check.checked=a.editar===true;
   check.onchange=()=>{a.editar=check.checked;state.dirty=true};
   edit.append(check,document.createTextNode('Puede registrar y modificar sus propios informes'));card.append(edit);
   card.append(element('small','Seleccionar las áreas se realiza en el paso siguiente. Áreas actuales: '+(a.areas||[]).length));
  }else card.append(element('small','Sin acceso a esta tarjeta.'));
  p.append(card);
 }
}
function available(m){return state.areas.filter(a=>a.modulo===m&&a.activa!==false)}
function stepSpecial(p,quick=false){
 p.append(element('h3',quick?'Áreas y facultades especiales':'4. Áreas y facultades especiales'));
 for(const m of W.modules){
  const a=state.draft.ambitos[m],card=element('section',undefined,'hys265-module');
  card.append(element('h4',scopeNames[m]));
  if(!a?.ver){card.append(element('p','Tarjeta deshabilitada.'));p.append(card);continue}
  const ids=available(m).map(x=>x.id);
  const all=ids.length>0&&ids.every(id=>a.areas.includes(id));
  const options=element('div',undefined,'hys265-inline');
  for(const [key,title]of [['all','Todas las áreas activas'],['selected','Seleccionar áreas']]){
   const rd=document.createElement('label');rd.className='hys265-checkline';
   const input=document.createElement('input');input.type='radio';input.name='area-'+m;input.checked=(state.draft.areaModes?.[m]|| (all?'all':'selected'))===key;
   input.onchange=()=>{state.draft.areaModes={...state.draft.areaModes,[m]:key};
    if(key==='all')a.areas=[...ids];
    state.draft.facultades[m].areas_ids=[...(a.areas||[])];state.dirty=true;render();
   };
   rd.append(input,document.createTextNode(title));options.append(rd);
  }
  card.append(options);
  if((state.draft.areaModes?.[m]||(all?'all':'selected'))==='selected'){
   const grid=element('div',undefined,'hys265-checkgrid');
   for(const area of available(m)){
    const lbl=document.createElement('label');lbl.className='hys265-checkline';
    const ch=document.createElement('input');ch.type='checkbox';ch.checked=a.areas.includes(area.id);
    ch.onchange=()=>{a.areas=ch.checked?[...new Set([...a.areas,area.id])]:a.areas.filter(id=>id!==area.id);state.draft.facultades[m].areas_ids=[...a.areas];state.dirty=true};
    lbl.append(ch,document.createTextNode(area.nombre));grid.append(lbl);
   }card.append(grid);
  }
  if(state.draft.rol==='administrador_area'){
   card.append(element('h4','Facultades de Administrador (por tarjeta)'));
   card.append(element('small','No hay autorizaciones automáticas. Marca explícitamente cada facultad que deseas conceder.'));
   const grid=element('div',undefined,'hys265-checkgrid');
   for(const [key,title] of rights){
    const lbl=document.createElement('label');lbl.className='hys265-checkline';
    const ch=document.createElement('input');ch.type='checkbox';ch.checked=state.draft.facultades[m]?.facultades?.[key]===true;
    ch.onchange=()=>{
     const granted=state.draft.facultades[m].facultades;
     granted[key]=ch.checked;
     const dependent=['pdf','review','approve','close','closeFlashReport','closeFinalReport','editOthers'];
     if(ch.checked&&dependent.includes(key))granted.view=true;
     if(key==='view'&&!ch.checked)for(const dep of dependent)granted[dep]=false;
     state.draft.facultades[m].areas_ids=[...a.areas];state.dirty=true;render();
    };
    lbl.append(ch,document.createTextNode(title));grid.append(lbl);
   }
   card.append(grid);
  }else card.append(element('p','Este rol no recibe facultades administrativas.','hys265-muted'));
  p.append(card);
 }
}
function stepReview(p){
 const d=state.draft,w=d.worker;
 p.append(element('h3','5. Revisar y confirmar'));
 const summary=element('dl',undefined,'hys265-summary');
 const add=(k,v)=>{summary.append(element('dt',k),element('dd',v||'No indicado'))};
 add('Trabajador',w.nombre);add('Documento',W.validDocument(w.rut,w.pais_documento,w.tipo_documento)?w.pais_documento+' · '+w.tipo_documento.toUpperCase()+' · Registrado':'Pendiente de validar');
 add('Cargo',w.cargo);add('Gerencia',w.gerencia);add('Empresa',w.empresa);add('Proyecto',w.proyecto);add('Supervisor responsable',userName(w.supervisor_id));
 add('Correo corporativo',w.correo_corporativo?'Registrado':'Sin correo corporativo');add('Correo personal',w.correo_personal?'Registrado':'Sin correo personal');
 const account=W.validateAccount(d.cuenta,w,state.mode==='edit');
 add('Cuenta de acceso',account.cuenta.email?'Configurada con correo '+account.cuenta.correo_ingreso:'Pendiente');add('Método de alta',state.mode==='edit'?'Cuenta existente':({automatica:'Contraseña automática',manual:'Contraseña manual',invitacion:'Invitación por correo'}[d.cuenta.metodo]||'Pendiente'));
 add('Rol',({administrador_area:'Administrador',supervisor:'Supervisor',usuario:'Usuario'}[d.rol]));
 for(const m of W.modules){
  const a=d.ambitos[m];add(scopeNames[m],a.ver?(a.areas||[]).length+' áreas; '+(a.editar?'edición propia':'solo consulta'):'Sin acceso');
  if(d.rol==='administrador_area'&&a.ver)add('Facultades de '+scopeNames[m],Object.values(d.facultades[m]?.facultades||{}).filter(Boolean).length+' seleccionadas');
 }
 p.append(summary);
 const label=document.createElement('label');label.textContent='Motivo obligatorio de creación o modificación *';
 const input=document.createElement('textarea');input.rows=3;input.maxLength=500;input.value=d.motivo;
 input.placeholder='Describe el motivo de esta creación o cambio (mínimo 10 caracteres)';
 input.oninput=()=>{d.motivo=input.value;state.dirty=true};
 label.append(input);p.append(label);
 p.append(element('p',lab?'Se guardará junto con roles, tarjetas, áreas y facultades en el laboratorio ficticio.':'El guardado real aún no está habilitado: falta crear y auditar la estructura de datos laborales y la operación transaccional en Supabase.','hys265-muted'));
}
function validateStep(step){
 const d=state.draft;
 if(step===1){const v=W.validate(d.worker,state.users,state.selected||'',{turnos:state.turnos});if(!v.ok)return v.errors.join('. ');d.worker=v.worker}
 if(step===2){const a=W.validateAccount(d.cuenta,d.worker,state.mode==='edit');if(!a.ok)return a.errors.join('. ');if(state.mode!=='edit'){const v=Credentials.validate(d.cuenta.metodo,credentialSecret,credentialRepeat);if(!v.ok)return v.error}d.cuenta=a.cuenta}
 if(step===3){if(!W.roles.includes(d.rol))return 'Selecciona un rol válido';if(!W.modules.some(m=>d.ambitos[m]?.ver))return 'Habilita al menos una tarjeta'}
 if(step===4){const r=W.validConfiguration(d.rol,d.ambitos,d.facultades,state.areas);if(!r.ok)return r.errors.join('. ')}
 return '';
}
function showInlineError(message){
 const el=$('hys265InlineError');
 if(el){
  el.hidden=false;el.replaceChildren();
  el.append(element('strong','Faltan datos para avanzar.'));
  el.append(element('p',message));
  el.scrollIntoView({behavior:'smooth',block:'nearest'});
 }
 notice('Revisa el aviso junto al botón Continuar: '+message,true);
 if(state.step===1){
  const w=state.draft.worker;
  const invalid={nombre:!w.nombre?.trim(),rut:!W.validDocument(w.rut,w.pais_documento,w.tipo_documento),cargo:!w.cargo?.trim(),gerencia:!w.gerencia?.trim(),
   empresa:!w.empresa?.trim(),proyecto:!w.proyecto?.trim(),pais_documento:!w.pais_documento,tipo_documento:!w.tipo_documento,supervisor_id:!w.supervisor_id,
   correo_corporativo:!w.correo_corporativo&&!w.correo_personal};
  for(const [name,flag]of Object.entries(invalid)){
   const input=$('hys265StepContent')?.querySelector('[name="'+name+'"]');
   if(input){input.classList.toggle('hys265-invalid',!!flag);input.setAttribute('aria-invalid',String(!!flag))}
  }
 }
}
function goNext(){
 const error=validateStep(state.step);
 if(error){showInlineError(error);return}
 state.step=Math.min(5,state.step+1);render();notice('Paso '+state.step+' de 5. Revisa los datos antes de continuar.');
}
async function save(){
 if(!lab){notice('Guardado bloqueado para usuarios reales. Falta migración Supabase, autorización transaccional y pruebas de auditoría; los cambios no se enviaron.',true);return}
 const errs=[1,2,3,4].map(validateStep).filter(Boolean);if(errs.length){notice(errs.join('. '),true);return}
 const d=state.draft;
 if(String(d.motivo).trim().length<10){notice('Describe el motivo del cambio con al menos 10 caracteres.',true);return}
 const payload=clone({...d,trabajador:d.worker,confirmar_facultades_nuevas:true});
 try{
  const deliveryCopy=state.mode==='create'?{email:d.cuenta.email,method:d.cuenta.metodo,secret:d.cuenta.metodo==='invitacion'?'':credentialSecret}:null;
  if(state.mode==='edit'){
   const u=state.users.find(x=>x.usuario_id===state.selected);
   if(!u)throw Error('La cuenta ya no está disponible');
   labApi.updateWorker(u.usuario_id,payload,u.revision);
  }else labApi.createWorker(payload);
  state.dirty=false;state.tab=deliveryCopy?'create':'directory';resetDraft();
  if(deliveryCopy){delivery=deliveryCopy;state.mode='delivery'}
  await refresh();
  notice(deliveryCopy?'Cuenta FICTICIA registrada. Copia o comparte el acceso antes de finalizar; solo se mostrará en esta pantalla.':'Cuenta FICTICIA modificada correctamente. Revisa Historial.');
 }catch(e){notice('No se pudo guardar: '+e.message,true)}
}
async function open(tab='directory',userId=null){
 if(!isGlobal())return;
 if(!panel.hidden&&!abandon())return;
 const actor=root.__REPORTES_HYS_ACCESS__?.userId;
 state.tab=tab;state.dirty=false;panel.hidden=false;
 await refresh();
 // Una sesión revocada o sustituida durante la consulta jamás abre el editor.
 if(!isGlobal()||panel.hidden||root.__REPORTES_HYS_ACCESS__?.userId!==actor)return;
 if(tab==='create')resetDraft();
 if(userId){const u=state.users.find(x=>x.usuario_id===userId);if(u)openEdit(u)}
 else render();
}
const close=()=>{if(!abandon())return false;clearCredentials();panel.hidden=true;state.dirty=false;inFlight++;if(!usersButton.hidden)usersButton.focus();return true};
$('hys265Close').onclick=close;
panel.querySelectorAll('[data-hys265-tab]').forEach(b=>b.onclick=()=>show(b.dataset.hys265Tab));
usersButton.onclick=()=>open('directory');
// Áreas y opciones mantiene su controlador original de v264 (cloud-v242.js).
// No convertir nunca el menú Áreas y opciones en una entrada a Gestión de usuarios.
function sync(){
 const visible=showInRail();
 usersButton.hidden=!visible;
 // Montar el control REAL de Apariencia si la inicialización inicial ocurrió antes de crear la cinta.
 // Se conserva su mismo panel y sus opciones; nunca se crea un duplicado.
 if(visible)root.HysAppearance242?.mount?.();
 const appearanceNow=$('appearanceOpen242')||appearance;
 if(appearanceNow&&appearanceNow.parentElement!==nav)nav.append(appearanceNow);
 if(appearanceNow){
  appearanceNow.hidden=!visible;
  appearanceNow.style.removeProperty('display');
 }
 // Áreas y opciones utiliza su botón original (y su panel histórico).
 if(areasButton)areasButton.hidden=!visible;
 if(oldUsers){oldUsers.hidden=true;oldUsers.style.display='none'}
 for(const b of [...nav.querySelectorAll('.hys-admin-open')]){
  if(b===usersButton||b===areasButton||b===follow||b===appearanceNow||b.id==='hys285OpenPillars'||b.id==='hys305OpenAccidents')continue;
  b.hidden=true;b.style.display='none';
 }
 if(!isGlobal()&&!panel.hidden){clearCredentials();state.dirty=false;panel.hidden=true;state.users=[];state.history=[]}
}
const previousSync=root.reportesHysAdminSync;
root.reportesHysAdminSync=()=>{previousSync?.();sync()};
sync();
root.addEventListener('reportes-hys-regimenes-updated',()=>{if(!panel.hidden&&!state.dirty)refresh()});
root.Hys265UserManagement={open,close,refresh,isLab:lab};
})(window);
